#!/bin/bash

# Run all experiments for SALOM paper
# This script trains all baseline methods and SALOM

echo "========================================="
echo "SALOM Experiments - Training All Methods"
echo "========================================="

# Create results directory
mkdir -p results

# Set common parameters
EPISODES=3000
SEED=42

# Train Greedy baseline
echo ""
echo "Training Greedy baseline..."
python src/main.py --method Greedy --episodes $EPISODES --seed $SEED

# Train DQN
echo ""
echo "Training DQN..."
python src/main.py --method DQN --episodes $EPISODES --seed $SEED

# Train PAPPO
echo ""
echo "Training PAPPO..."
python src/main.py --method PAPPO --episodes $EPISODES --seed $SEED

# Train Meta-RL
echo ""
echo "Training Meta-RL..."
python src/main.py --method MetaRL --episodes $EPISODES --seed $SEED

# Train LyDROO
echo ""
echo "Training LyDROO..."
python src/main.py --method LyDROO --episodes $EPISODES --seed $SEED

# Train SALOM
echo ""
echo "Training SALOM..."
python src/main.py --method SALOM --episodes $EPISODES --seed $SEED

echo ""
echo "========================================="
echo "All experiments completed!"
echo "Results saved in results/ directory"
echo "========================================="
