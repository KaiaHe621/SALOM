#!/bin/bash
# Quick script to generate multiple datasets with different seeds

echo "Generating MEC Datasets..."
echo "=========================="

# Create data directory
mkdir -p data

# Generate datasets with different seeds for reproducibility
seeds=(42 123 456 789 2024)

for seed in "${seeds[@]}"
do
    echo ""
    echo "Generating dataset with seed $seed..."
    python src/generate_dataset.py --output_dir data --num_samples 10000 --seed $seed
done

echo ""
echo "=========================="
echo "All datasets generated!"
echo "Location: data/"
echo ""
echo "Generated files:"
ls -lh data/

echo ""
echo "To use the datasets, see DATASET_README.md"
