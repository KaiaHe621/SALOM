#!/bin/bash

# Run all experiments for SALOM paper
# This script trains all methods and compares their performance

echo "Starting SALOM Experiments..."
echo "=============================="

# Create results directory
mkdir -p results

# Set common parameters
EPISODES=3000
SEED=42
DEVICE="cuda"

# Train SALOM
echo ""
echo "Training SALOM..."
python src/main.py --method SALOM --episodes $EPISODES --seed $SEED --device $DEVICE

# Train DQN
echo ""
echo "Training DQN..."
python src/main.py --method DQN --episodes $EPISODES --seed $SEED --device $DEVICE

# Train PAPPO
echo ""
echo "Training PAPPO..."
python src/main.py --method PAPPO --episodes $EPISODES --seed $SEED --device $DEVICE

# Train Meta-RL
echo ""
echo "Training Meta-RL..."
python src/main.py --method MetaRL --episodes $EPISODES --seed $SEED --device $DEVICE

# Train LyDROO
echo ""
echo "Training LyDROO..."
python src/main.py --method LyDROO --episodes $EPISODES --seed $SEED --device $DEVICE

# Train Greedy
echo ""
echo "Training Greedy..."
python src/main.py --method Greedy --episodes $EPISODES --seed $SEED --device $DEVICE

echo ""
echo "=============================="
echo "All experiments completed!"
echo "Results saved in results/ directory"
