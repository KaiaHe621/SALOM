"""
Main training script for SALOM
"""

import argparse
import yaml
import numpy as np
import torch
import os
from datetime import datetime
import matplotlib.pyplot as plt
from tqdm import tqdm

from environment import MECEnvironment
from salom_agent import SALOMAgent
from baseline_agents import DQNAgent, PAPPOAgent, MetaRLAgent, LyDROOAgent, GreedyAgent


def parse_args():
    parser = argparse.ArgumentParser(description='SALOM Training')
    parser.add_argument('--config', type=str, default='config/config.yaml')
    parser.add_argument('--method', type=str, default='SALOM', 
                       choices=['SALOM', 'DQN', 'PAPPO', 'MetaRL', 'LyDROO', 'Greedy'])
    parser.add_argument('--episodes', type=int, default=3000)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--device', type=str, default='cuda')
    parser.add_argument('--save_dir', type=str, default='results')
    return parser.parse_args()


def set_seed(seed):
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)


def create_agent(method, state_dim, action_dim, feature_dims, config, device):
    if method == 'SALOM':
        return SALOMAgent(state_dim, action_dim, feature_dims, config, device)
    elif method == 'DQN':
        return DQNAgent(state_dim, action_dim, config, device)
    elif method == 'PAPPO':
        return PAPPOAgent(state_dim, action_dim, config, device)
    elif method == 'MetaRL':
        return MetaRLAgent(state_dim, action_dim, config, device)
    elif method == 'LyDROO':
        return LyDROOAgent(state_dim, action_dim, config, device)
    elif method == 'Greedy':
        return GreedyAgent(state_dim, action_dim, config)
    else:
        raise ValueError(f"Unknown method: {method}")


def train_episode(env, agent, method):
    state = env.reset()
    episode_reward = 0
    episode_latency = 0
    episode_completed = 0
    episode_violations = 0
    
    done = False
    step = 0
    
    while not done:
        service_priority = env.tasks[0].priority
        action = agent.select_action(state, service_priority)
        next_state, reward, done, info = env.step(action)
        
        if method != 'Greedy':
            agent.store_transition(state, action, reward, next_state, done, service_priority)
            agent.train()
        
        episode_reward += reward
        episode_latency += info['average_latency']
        episode_completed += info['completed_tasks']
        episode_violations += info['sla_violations']
        
        state = next_state
        step += 1
    
    return {
        'reward': episode_reward,
        'latency': episode_latency / step,
        'completed': episode_completed,
        'violations': episode_violations,
        'completion_rate': episode_completed / (episode_completed + episode_violations + 1e-8)
    }


def evaluate(env, agent, method, num_episodes=10):
    eval_rewards = []
    eval_latencies = []
    eval_completions = []
    eval_violations = []
    
    for _ in range(num_episodes):
        state = env.reset()
        episode_reward = 0
        episode_latency = 0
        episode_completed = 0
        episode_violations = 0
        
        done = False
        step = 0
        
        while not done:
            service_priority = env.tasks[0].priority
            action = agent.select_action(state, service_priority, evaluate=True)
            next_state, reward, done, info = env.step(action)
            
            episode_reward += reward
            episode_latency += info['average_latency']
            episode_completed += info['completed_tasks']
            episode_violations += info['sla_violations']
            
            state = next_state
            step += 1
        
        eval_rewards.append(episode_reward)
        eval_latencies.append(episode_latency / step)
        eval_completions.append(episode_completed)
        eval_violations.append(episode_violations)
    
    return {
        'mean_reward': np.mean(eval_rewards),
        'mean_latency': np.mean(eval_latencies),
        'mean_completed': np.mean(eval_completions),
        'mean_violations': np.mean(eval_violations),
        'completion_rate': np.mean(eval_completions) / (np.mean(eval_completions) + np.mean(eval_violations) + 1e-8)
    }


def plot_results(results, save_path):
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    
    axes[0, 0].plot(results['rewards'])
    axes[0, 0].set_title('Episode Reward')
    axes[0, 0].set_xlabel('Episode')
    axes[0, 0].set_ylabel('Reward')
    axes[0, 0].grid(True)
    
    axes[0, 1].plot(results['latencies'])
    axes[0, 1].set_title('Average Latency')
    axes[0, 1].set_xlabel('Episode')
    axes[0, 1].set_ylabel('Latency (s)')
    axes[0, 1].grid(True)
    
    axes[1, 0].plot(results['completion_rates'])
    axes[1, 0].set_title('Task Completion Rate')
    axes[1, 0].set_xlabel('Episode')
    axes[1, 0].set_ylabel('Completion Rate')
    axes[1, 0].grid(True)
    
    axes[1, 1].plot(results['violations'])
    axes[1, 1].set_title('SLA Violations')
    axes[1, 1].set_xlabel('Episode')
    axes[1, 1].set_ylabel('Violations')
    axes[1, 1].grid(True)
    
    plt.tight_layout()
    plt.savefig(save_path)
    plt.close()


def main():
    args = parse_args()
    
    with open(args.config, 'r') as f:
        config = yaml.safe_load(f)
    
    set_seed(args.seed)
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    save_dir = os.path.join(args.save_dir, f'{args.method}_{timestamp}')
    os.makedirs(save_dir, exist_ok=True)
    
    env = MECEnvironment(config)
    state_dim = env.state_dim
    action_dim = env.action_dim
    feature_dims = env.get_feature_dims()
    
    print(f"Environment: state_dim={state_dim}, action_dim={action_dim}")
    
    agent = create_agent(args.method, state_dim, action_dim, feature_dims, config, args.device)
    print(f"Agent: {args.method}")
    
    results = {
        'rewards': [],
        'latencies': [],
        'completion_rates': [],
        'violations': []
    }
    
    best_reward = -float('inf')
    
    print(f"\nTraining for {args.episodes} episodes...")
    
    for episode in tqdm(range(args.episodes)):
        episode_info = train_episode(env, agent, args.method)
        
        results['rewards'].append(episode_info['reward'])
        results['latencies'].append(episode_info['latency'])
        results['completion_rates'].append(episode_info['completion_rate'])
        results['violations'].append(episode_info['violations'])
        
        if (episode + 1) % 100 == 0:
            print(f"\nEpisode {episode + 1}/{args.episodes}")
            print(f"  Reward: {episode_info['reward']:.2f}")
            print(f"  Latency: {episode_info['latency']:.4f}s")
            print(f"  Completion Rate: {episode_info['completion_rate']:.2%}")
            
            eval_info = evaluate(env, agent, args.method, num_episodes=10)
            print(f"  Eval Reward: {eval_info['mean_reward']:.2f}")
            print(f"  Eval Latency: {eval_info['mean_latency']:.4f}s")
            
            if eval_info['mean_reward'] > best_reward:
                best_reward = eval_info['mean_reward']
                if args.method != 'Greedy':
                    agent.save(os.path.join(save_dir, 'model_best.pth'))
                print(f"  Best model saved!")
        
        if (episode + 1) % 500 == 0 and args.method != 'Greedy':
            agent.save(os.path.join(save_dir, f'model_ep{episode+1}.pth'))
    
    print("\nFinal Evaluation...")
    final_eval = evaluate(env, agent, args.method, num_episodes=50)
    print(f"Mean Reward: {final_eval['mean_reward']:.2f}")
    print(f"Mean Latency: {final_eval['mean_latency']:.4f}s")
    print(f"Completion Rate: {final_eval['completion_rate']:.2%}")
    
    np.save(os.path.join(save_dir, 'results.npy'), results)
    plot_results(results, os.path.join(save_dir, 'training_curves.png'))
    
    with open(os.path.join(save_dir, 'config.yaml'), 'w') as f:
        yaml.dump(config, f)
    
    print(f"\nResults saved to {save_dir}")


if __name__ == '__main__':
    main()
