"""
Utility functions for SALOM
"""

import numpy as np
import torch
import random
import os
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.ndimage import gaussian_filter1d


def set_seed(seed):
    """Set random seed for reproducibility"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False


def smooth_curve(data, sigma=2):
    """Smooth curve using Gaussian filter"""
    return gaussian_filter1d(data, sigma=sigma)


def plot_comparison(results_dict, save_path, metric='latency'):
    """
    Plot comparison of different methods
    
    Args:
        results_dict: dict of {method_name: results}
        save_path: path to save figure
        metric: metric to plot ('latency', 'completion_rate', 'reward')
    """
    plt.figure(figsize=(10, 6))
    
    for method_name, results in results_dict.items():
        if metric in results:
            data = results[metric]
            smoothed = smooth_curve(data, sigma=10)
            plt.plot(smoothed, label=method_name, linewidth=2)
    
    plt.xlabel('Episode', fontsize=12)
    
    if metric == 'latency':
        plt.ylabel('Average Latency (s)', fontsize=12)
        plt.title('Average Latency Comparison', fontsize=14)
    elif metric == 'completion_rate':
        plt.ylabel('Task Completion Rate', fontsize=12)
        plt.title('Task Completion Rate Comparison', fontsize=14)
    elif metric == 'reward':
        plt.ylabel('Episode Reward', fontsize=12)
        plt.title('Episode Reward Comparison', fontsize=14)
    
    plt.legend(fontsize=10)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(save_path, dpi=300)
    plt.close()


def compute_statistics(data):
    """Compute statistics for data"""
    return {
        'mean': np.mean(data),
        'std': np.std(data),
        'min': np.min(data),
        'max': np.max(data),
        'median': np.median(data)
    }


def save_results(results, save_dir):
    """Save results to file"""
    os.makedirs(save_dir, exist_ok=True)
    
    # Save numpy arrays
    for key, value in results.items():
        if isinstance(value, (list, np.ndarray)):
            np.save(os.path.join(save_dir, f'{key}.npy'), value)
    
    # Save statistics
    stats = {}
    for key, value in results.items():
        if isinstance(value, (list, np.ndarray)):
            stats[key] = compute_statistics(value)
    
    import json
    with open(os.path.join(save_dir, 'statistics.json'), 'w') as f:
        json.dump(stats, f, indent=4)


def load_results(save_dir):
    """Load results from file"""
    results = {}
    
    for file in os.listdir(save_dir):
        if file.endswith('.npy'):
            key = file[:-4]
            results[key] = np.load(os.path.join(save_dir, file))
    
    return results


class MovingAverage:
    """Compute moving average"""
    def __init__(self, window_size=100):
        self.window_size = window_size
        self.values = []
    
    def add(self, value):
        self.values.append(value)
        if len(self.values) > self.window_size:
            self.values.pop(0)
    
    def get(self):
        if len(self.values) == 0:
            return 0.0
        return np.mean(self.values)


def print_progress(episode, total_episodes, metrics):
    """Print training progress"""
    progress = (episode + 1) / total_episodes * 100
    print(f"\nEpisode {episode + 1}/{total_episodes} ({progress:.1f}%)")
    for key, value in metrics.items():
        if isinstance(value, float):
            print(f"  {key}: {value:.4f}")
        else:
            print(f"  {key}: {value}")
