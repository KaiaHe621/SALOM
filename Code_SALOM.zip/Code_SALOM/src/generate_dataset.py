"""
Dataset Generator for SALOM Experiments
Generates reproducible datasets for MEC task offloading experiments
"""

import numpy as np
import json
import os
from datetime import datetime
import argparse


class MECDatasetGenerator:
    """Generate MEC task offloading datasets"""
    
    def __init__(self, config):
        self.config = config
        self.seed = config.get('seed', 42)
        np.random.seed(self.seed)
    
    def generate_network_traces(self, num_samples=10000):
        """
        Generate network bandwidth traces
        Simulates realistic network conditions with temporal correlation
        """
        traces = []
        
        # Base bandwidth (Mbps)
        base_4g = np.random.uniform(50, 150, num_samples)
        base_5g = np.random.uniform(200, 500, num_samples)
        
        # Network type (70% 4G, 30% 5G)
        network_type = np.random.choice([0, 1], size=num_samples, p=[0.7, 0.3])
        
        for i in range(num_samples):
            if network_type[i] == 0:  # 4G
                bandwidth = base_4g[i]
            else:  # 5G
                bandwidth = base_5g[i]
            
            # Add temporal correlation (smooth transitions)
            if i > 0:
                bandwidth = 0.7 * bandwidth + 0.3 * traces[-1]['bandwidth']
            
            # Add random fluctuations
            bandwidth *= np.random.uniform(0.8, 1.2)
            
            traces.append({
                'timestamp': i,
                'bandwidth': float(bandwidth * 1e6),  # Convert to bps
                'network_type': '5G' if network_type[i] == 1 else '4G',
                'signal_strength': float(np.random.uniform(-90, -50))  # dBm
            })
        
        return traces
    
    def generate_server_traces(self, num_servers=5, num_samples=10000):
        """Generate edge server state traces"""
        server_traces = []
        
        for server_id in range(num_servers):
            traces = []
            
            # Server characteristics
            cpu_freq = np.random.uniform(2.8, 3.5) * 1e9  # Hz
            base_load = np.random.uniform(0.2, 0.5)
            
            for i in range(num_samples):
                # Load varies over time
                load = base_load + 0.3 * np.sin(2 * np.pi * i / 1000) + np.random.uniform(-0.1, 0.1)
                load = np.clip(load, 0.0, 1.0)
                
                # Queue length correlates with load
                queue_length = int(load * 20 + np.random.poisson(5))
                
                traces.append({
                    'timestamp': i,
                    'server_id': server_id,
                    'cpu_frequency': float(cpu_freq),
                    'load': float(load),
                    'queue_length': queue_length,
                    'available_capacity': float(1.0 - load)
                })
            
            server_traces.append(traces)
        
        return server_traces
    
    def generate_task_traces(self, num_samples=10000):
        """Generate task arrival traces with different service types"""
        tasks = []
        
        service_types = ['industrial_control', 'video_streaming', 'file_download']
        priorities = [3, 2, 1]
        
        for i in range(num_samples):
            # Service type distribution
            service_idx = np.random.choice([0, 1, 2], p=[0.3, 0.4, 0.3])
            service_type = service_types[service_idx]
            priority = priorities[service_idx]
            
            # Task parameters based on service type
            if service_idx == 0:  # Industrial control
                data_size = np.random.uniform(0.2, 0.8) * 1e6  # bytes
                computation = np.random.uniform(5e8, 2e9)  # cycles
                max_latency = 0.05  # 50ms
            elif service_idx == 1:  # Video streaming
                data_size = np.random.uniform(1.0, 3.0) * 1e6
                computation = np.random.uniform(8e8, 5e9)
                max_latency = 0.2  # 200ms
            else:  # File download
                data_size = np.random.uniform(2.0, 8.0) * 1e6
                computation = np.random.uniform(3e8, 1.5e9)
                max_latency = 0.5  # 500ms
            
            tasks.append({
                'task_id': i,
                'timestamp': i,
                'service_type': service_type,
                'priority': priority,
                'data_size': float(data_size),
                'computation_cycles': float(computation),
                'max_latency': float(max_latency),
                'arrival_time': float(i * 0.01)  # 10ms intervals
            })
        
        return tasks
    
    def generate_mutation_events(self, num_samples=10000, num_mutations=5):
        """Generate environmental mutation events"""
        mutations = []
        
        mutation_times = sorted(np.random.choice(
            range(1000, num_samples - 1000), 
            size=num_mutations, 
            replace=False
        ))
        
        mutation_types = ['bandwidth_drop', 'bandwidth_surge', 'server_overload', 
                         'server_recovery', 'network_congestion']
        
        for i, time in enumerate(mutation_times):
            mutation_type = np.random.choice(mutation_types)
            
            if mutation_type == 'bandwidth_drop':
                params = {'factor': float(np.random.uniform(0.3, 0.6))}
            elif mutation_type == 'bandwidth_surge':
                params = {'factor': float(np.random.uniform(1.5, 2.0))}
            elif mutation_type == 'server_overload':
                params = {
                    'affected_servers': list(np.random.choice(5, size=2, replace=False).astype(int)),
                    'load_increase': float(np.random.uniform(0.3, 0.5))
                }
            elif mutation_type == 'server_recovery':
                params = {'recovery_rate': float(np.random.uniform(0.5, 0.8))}
            else:  # network_congestion
                params = {
                    'duration': int(np.random.randint(50, 200)),
                    'severity': float(np.random.uniform(0.4, 0.7))
                }
            
            mutations.append({
                'mutation_id': i,
                'timestamp': int(time),
                'type': mutation_type,
                'parameters': params,
                'duration': int(np.random.randint(100, 500))
            })
        
        return mutations
    
    def generate_complete_dataset(self, output_dir='data', num_samples=10000):
        """Generate complete dataset with all components"""
        os.makedirs(output_dir, exist_ok=True)
        
        print("Generating MEC Dataset...")
        print(f"  Samples: {num_samples}")
        print(f"  Seed: {self.seed}")
        
        # Generate all components
        print("\n[1/4] Generating network traces...")
        network_traces = self.generate_network_traces(num_samples)
        
        print("[2/4] Generating server traces...")
        server_traces = self.generate_server_traces(num_servers=5, num_samples=num_samples)
        
        print("[3/4] Generating task traces...")
        task_traces = self.generate_task_traces(num_samples)
        
        print("[4/4] Generating mutation events...")
        mutations = self.generate_mutation_events(num_samples, num_mutations=5)
        
        # Create dataset metadata
        metadata = {
            'dataset_name': 'MEC_Task_Offloading_Dataset',
            'version': '1.0',
            'generated_at': datetime.now().isoformat(),
            'seed': self.seed,
            'num_samples': num_samples,
            'num_servers': 5,
            'num_mutations': len(mutations),
            'service_types': ['industrial_control', 'video_streaming', 'file_download'],
            'description': 'Synthetic dataset for mobile edge computing task offloading experiments'
        }
        
        # Save dataset
        dataset = {
            'metadata': metadata,
            'network_traces': network_traces,
            'server_traces': server_traces,
            'task_traces': task_traces,
            'mutation_events': mutations
        }
        
        # Save as JSON
        output_file = os.path.join(output_dir, f'mec_dataset_seed{self.seed}.json')
        print(f"\nSaving dataset to {output_file}...")
        with open(output_file, 'w') as f:
            json.dump(dataset, f, indent=2)
        
        # Save statistics
        stats = self._compute_statistics(dataset)
        stats_file = os.path.join(output_dir, f'dataset_statistics_seed{self.seed}.json')
        with open(stats_file, 'w') as f:
            json.dump(stats, f, indent=2)
        
        print(f"\n✓ Dataset generated successfully!")
        print(f"  Output: {output_file}")
        print(f"  Size: {os.path.getsize(output_file) / 1024 / 1024:.2f} MB")
        print(f"  Statistics: {stats_file}")
        
        return dataset
    
    def _compute_statistics(self, dataset):
        """Compute dataset statistics"""
        network = dataset['network_traces']
        tasks = dataset['task_traces']
        
        # Network statistics
        bandwidths = [t['bandwidth'] for t in network]
        
        # Task statistics by service type
        task_stats = {}
        for service_type in ['industrial_control', 'video_streaming', 'file_download']:
            service_tasks = [t for t in tasks if t['service_type'] == service_type]
            if service_tasks:
                task_stats[service_type] = {
                    'count': len(service_tasks),
                    'avg_data_size': float(np.mean([t['data_size'] for t in service_tasks])),
                    'avg_computation': float(np.mean([t['computation_cycles'] for t in service_tasks])),
                    'avg_max_latency': float(np.mean([t['max_latency'] for t in service_tasks]))
                }
        
        stats = {
            'network': {
                'avg_bandwidth': float(np.mean(bandwidths)),
                'std_bandwidth': float(np.std(bandwidths)),
                'min_bandwidth': float(np.min(bandwidths)),
                'max_bandwidth': float(np.max(bandwidths))
            },
            'tasks': task_stats,
            'mutations': {
                'count': len(dataset['mutation_events']),
                'types': list(set([m['type'] for m in dataset['mutation_events']]))
            }
        }
        
        return stats


def main():
    parser = argparse.ArgumentParser(description='Generate MEC Dataset')
    parser.add_argument('--output_dir', type=str, default='data', help='Output directory')
    parser.add_argument('--num_samples', type=int, default=10000, help='Number of samples')
    parser.add_argument('--seed', type=int, default=42, help='Random seed')
    args = parser.parse_args()
    
    config = {
        'seed': args.seed
    }
    
    generator = MECDatasetGenerator(config)
    dataset = generator.generate_complete_dataset(
        output_dir=args.output_dir,
        num_samples=args.num_samples
    )
    
    print("\n" + "="*60)
    print("Dataset Generation Complete!")
    print("="*60)


if __name__ == '__main__':
    main()
