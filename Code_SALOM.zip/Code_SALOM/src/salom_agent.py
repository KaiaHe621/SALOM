"""
SALOM Agent
Integrates FCO and DPER for service-aware latency optimization
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import numpy as np

from fco_module import FCOModule
from dper_buffer import DPERBuffer


class QNetwork(nn.Module):
    """Q-Network for SALOM"""
    def __init__(self, state_dim, action_dim, hidden_dims=[512, 256, 128]):
        super(QNetwork, self).__init__()
        
        layers = []
        prev_dim = state_dim
        for hidden_dim in hidden_dims:
            layers.append(nn.Linear(prev_dim, hidden_dim))
            layers.append(nn.ReLU())
            prev_dim = hidden_dim
        
        layers.append(nn.Linear(prev_dim, action_dim))
        
        self.network = nn.Sequential(*layers)
    
    def forward(self, state):
        return self.network(state)


class SALOMAgent:
    """
    SALOM Agent with FCO and DPER
    """
    def __init__(self, state_dim, action_dim, feature_dims, config, device='cuda'):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.config = config
        self.device = torch.device(device if torch.cuda.is_available() else 'cpu')
        
        # Q-Networks
        self.q_network = QNetwork(
            state_dim,
            action_dim,
            hidden_dims=config['salom']['dqn']['hidden_layers']
        ).to(self.device)
        
        self.target_network = QNetwork(
            state_dim,
            action_dim,
            hidden_dims=config['salom']['dqn']['hidden_layers']
        ).to(self.device)
        
        self.target_network.load_state_dict(self.q_network.state_dict())
        self.target_network.eval()
        
        # FCO Module
        self.fco = FCOModule(config['salom'], feature_dims).to(self.device)
        
        # DPER Buffer
        self.replay_buffer = DPERBuffer(
            capacity=config['salom']['dper']['buffer_size'],
            config=config['salom'],
            alpha=config['salom']['dper']['alpha'],
            beta_start=config['salom']['dper']['beta_start'],
            beta_frames=config['salom']['dper']['beta_frames']
        )
        
        # Optimizer
        self.optimizer = optim.Adam(
            list(self.q_network.parameters()) + list(self.fco.parameters()),
            lr=config['salom']['dqn']['learning_rate']
        )
        
        # Hyperparameters
        self.gamma = config['salom']['dqn']['gamma']
        self.tau = config['salom']['dqn']['tau']
        self.batch_size = config['salom']['dper']['batch_size']
        self.target_update_freq = config['salom']['dqn']['target_update_freq']
        self.alignment_loss_weight = config['salom']['fco']['alignment_loss_weight']
        
        # Epsilon for exploration
        self.epsilon = config['salom']['dqn']['epsilon_start']
        self.epsilon_end = config['salom']['dqn']['epsilon_end']
        self.epsilon_decay = config['salom']['dqn']['epsilon_decay']
        
        # Training step counter
        self.train_step = 0
    
    def select_action(self, state, service_priority, evaluate=False):
        """
        Select action using epsilon-greedy policy
        
        Args:
            state: current state
            service_priority: priority of current task
            evaluate: if True, use greedy policy
        
        Returns:
            action
        """
        if not evaluate and np.random.rand() < self.epsilon:
            # Random action
            action = np.random.rand(self.action_dim)
            # Normalize offloading decisions to probabilities
            num_devices = self.action_dim // (self.config['environment']['num_edge_servers'] + 2)
            num_servers = self.config['environment']['num_edge_servers']
            for i in range(num_devices):
                start_idx = i * num_servers
                end_idx = (i + 1) * num_servers
                action[start_idx:end_idx] = np.exp(action[start_idx:end_idx])
                action[start_idx:end_idx] /= action[start_idx:end_idx].sum()
            return action
        
        # Greedy action
        with torch.no_grad():
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            
            # Extract feature components for FCO
            network_dim, server_dim, task_dim = self.fco.network_dim, self.fco.server_dim, self.fco.task_dim
            network_features = state_tensor[:, :network_dim]
            server_features = state_tensor[:, network_dim:network_dim+server_dim]
            task_features = state_tensor[:, network_dim+server_dim:]
            
            # Apply FCO if needed
            calibrated_state, mutation_detected = self.fco(
                state_tensor,
                network_features,
                server_features,
                task_features
            )
            
            # Update DPER mutation mode
            if mutation_detected:
                self.replay_buffer.set_mutation_mode(True)
            
            # Get Q-values
            q_values = self.q_network(calibrated_state)
            action = q_values.cpu().numpy()[0]
            
            # Normalize offloading decisions
            num_devices = self.action_dim // (self.config['environment']['num_edge_servers'] + 2)
            num_servers = self.config['environment']['num_edge_servers']
            for i in range(num_devices):
                start_idx = i * num_servers
                end_idx = (i + 1) * num_servers
                action[start_idx:end_idx] = np.exp(action[start_idx:end_idx])
                action[start_idx:end_idx] /= action[start_idx:end_idx].sum()
            
            return action
    
    def store_transition(self, state, action, reward, next_state, done, service_priority):
        """Store transition in DPER buffer"""
        # Compute initial TD error (will be updated during training)
        with torch.no_grad():
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            next_state_tensor = torch.FloatTensor(next_state).unsqueeze(0).to(self.device)
            action_tensor = torch.FloatTensor(action).unsqueeze(0).to(self.device)
            
            # Current Q-value
            current_q = self.q_network(state_tensor).gather(1, action_tensor.long().argmax(1, keepdim=True))
            
            # Target Q-value
            next_q = self.target_network(next_state_tensor).max(1)[0].unsqueeze(1)
            target_q = reward + (1 - done) * self.gamma * next_q
            
            td_error = (target_q - current_q).abs().item()
        
        # Store in buffer
        self.replay_buffer.push(
            state, action, reward, next_state, done,
            service_priority, td_error
        )
        
        # Update current state for environmental similarity
        self.replay_buffer.update_current_state(state)
    
    def train(self):
        """Train the agent using DPER"""
        if len(self.replay_buffer) < self.batch_size:
            return None
        
        # Sample batch from DPER buffer
        batch, indices, weights = self.replay_buffer.sample(self.batch_size)
        
        # Prepare batch tensors
        states = torch.FloatTensor(np.array([t.state for t in batch])).to(self.device)
        actions = torch.FloatTensor(np.array([t.action for t in batch])).to(self.device)
        rewards = torch.FloatTensor(np.array([t.reward for t in batch])).unsqueeze(1).to(self.device)
        next_states = torch.FloatTensor(np.array([t.next_state for t in batch])).to(self.device)
        dones = torch.FloatTensor(np.array([t.done for t in batch])).unsqueeze(1).to(self.device)
        weights = torch.FloatTensor(weights).unsqueeze(1).to(self.device)
        
        # Extract feature components for FCO
        network_dim, server_dim, task_dim = self.fco.network_dim, self.fco.server_dim, self.fco.task_dim
        
        # Current states
        network_features = states[:, :network_dim]
        server_features = states[:, network_dim:network_dim+server_dim]
        task_features = states[:, network_dim+server_dim:]
        
        # Apply FCO
        calibrated_states, _ = self.fco(
            states,
            network_features,
            server_features,
            task_features
        )
        
        # Generate auxiliary features for alignment loss
        auxiliary_features = self.fco.auxiliary_net(
            network_features,
            server_features,
            task_features
        )
        
        # Compute Q-values
        current_q_values = self.q_network(calibrated_states)
        current_q = current_q_values.gather(1, actions.long().argmax(1, keepdim=True))
        
        # Compute target Q-values
        with torch.no_grad():
            # Next states
            next_network_features = next_states[:, :network_dim]
            next_server_features = next_states[:, network_dim:network_dim+server_dim]
            next_task_features = next_states[:, network_dim+server_dim:]
            
            calibrated_next_states, _ = self.fco(
                next_states,
                next_network_features,
                next_server_features,
                next_task_features
            )
            
            next_q_values = self.target_network(calibrated_next_states)
            next_q = next_q_values.max(1)[0].unsqueeze(1)
            target_q = rewards + (1 - dones) * self.gamma * next_q
        
        # Compute TD error
        td_errors = (target_q - current_q).abs()
        
        # Compute Q-loss with importance sampling weights
        q_loss = (weights * F.mse_loss(current_q, target_q, reduction='none')).mean()
        
        # Compute FCO alignment loss
        alignment_loss = self.fco.compute_alignment_loss(calibrated_states, auxiliary_features)
        
        # Total loss
        total_loss = q_loss + self.alignment_loss_weight * alignment_loss
        
        # Optimize
        self.optimizer.zero_grad()
        total_loss.backward()
        torch.nn.utils.clip_grad_norm_(self.q_network.parameters(), 1.0)
        torch.nn.utils.clip_grad_norm_(self.fco.parameters(), 1.0)
        self.optimizer.step()
        
        # Update priorities in DPER buffer
        self.replay_buffer.update_priorities(indices, td_errors.detach().cpu().numpy())
        
        # Soft update target network
        if self.train_step % self.target_update_freq == 0:
            self._soft_update_target_network()
        
        # Decay epsilon
        self.epsilon = max(self.epsilon_end, self.epsilon * self.epsilon_decay)
        
        self.train_step += 1
        
        return {
            'q_loss': q_loss.item(),
            'alignment_loss': alignment_loss.item(),
            'total_loss': total_loss.item(),
            'mean_q_value': current_q.mean().item()
        }
    
    def _soft_update_target_network(self):
        """Soft update target network parameters"""
        for target_param, param in zip(self.target_network.parameters(), self.q_network.parameters()):
            target_param.data.copy_(self.tau * param.data + (1 - self.tau) * target_param.data)
    
    def save(self, path):
        """Save model"""
        torch.save({
            'q_network': self.q_network.state_dict(),
            'target_network': self.target_network.state_dict(),
            'fco': self.fco.state_dict(),
            'optimizer': self.optimizer.state_dict(),
            'train_step': self.train_step,
            'epsilon': self.epsilon
        }, path)
    
    def load(self, path):
        """Load model"""
        checkpoint = torch.load(path, map_location=self.device)
        self.q_network.load_state_dict(checkpoint['q_network'])
        self.target_network.load_state_dict(checkpoint['target_network'])
        self.fco.load_state_dict(checkpoint['fco'])
        self.optimizer.load_state_dict(checkpoint['optimizer'])
        self.train_step = checkpoint['train_step']
        self.epsilon = checkpoint['epsilon']
