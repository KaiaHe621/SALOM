"""
Evaluation script for SALOM
"""

import argparse
import yaml
import numpy as np
import torch
import os
import matplotlib.pyplot as plt
from tqdm import tqdm

from environment import MECEnvironment
from salom_agent import SALOMAgent
from baseline_agents import DQNAgent, PAPPOAgent, MetaRLAgent, LyDROOAgent, GreedyAgent
from utils import set_seed, plot_comparison, save_results


def parse_args():
    parser = argparse.ArgumentParser(description='SALOM Evaluation')
    parser.add_argument('--config', type=str, default='config/config.yaml')
    parser.add_argument('--checkpoint', type=str, required=True, help='Path to checkpoint')
    parser.add_argument('--method', type=str, default='SALOM',
                       choices=['SALOM', 'DQN', 'PAPPO', 'MetaRL', 'LyDROO', 'Greedy'])
    parser.add_argument('--num_episodes', type=int, default=100)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--save_dir', type=str, default='eval_results')
    return parser.parse_args()


def create_agent(method, state_dim, action_dim, feature_dims, config, device):
    """Create agent"""
    if method == 'SALOM':
        return SALOMAgent(state_dim, action_dim, feature_dims, config, device)
    elif method == 'DQN':
        return DQNAgent(state_dim, action_dim, config, device)
    elif method == 'PAPPO':
        return PAPPOAgent(state_dim, action_dim, config, device)
    elif method == 'MetaRL':
        return MetaRLAgent(state_dim, action_dim, config, device)
    elif method == 'LyDROO':
        return LyDROOAgent(state_dim, action_dim, config, device)
    elif method == 'Greedy':
        return GreedyAgent(state_dim, action_dim, config)
    else:
        raise ValueError(f"Unknown method: {method}")


def evaluate_episode(env, agent, method):
    """Evaluate one episode"""
    state = env.reset()
    episode_reward = 0
    episode_latencies = []
    episode_completed = 0
    episode_violations = 0
    
    done = False
    step = 0
    
    while not done:
        service_priority = env.tasks[0].priority
        action = agent.select_action(state, service_priority, evaluate=True)
        next_state, reward, done, info = env.step(action)
        
        episode_reward += reward
        episode_latencies.append(info['average_latency'])
        episode_completed += info['completed_tasks']
        episode_violations += info['sla_violations']
        
        state = next_state
        step += 1
    
    return {
        'reward': episode_reward,
        'latency': np.mean(episode_latencies),
        'completed': episode_completed,
        'violations': episode_violations,
        'completion_rate': episode_completed / (episode_completed + episode_violations + 1e-8),
        'steps': step
    }


def main():
    args = parse_args()
    
    # Load config
    with open(args.config, 'r') as f:
        config = yaml.safe_load(f)
    
    # Set seed
    set_seed(args.seed)
    
    # Create environment
    env = MECEnvironment(config)
    state_dim = env.state_dim
    action_dim = env.action_dim
    feature_dims = env.get_feature_dims()
    
    print(f"Environment: state_dim={state_dim}, action_dim={action_dim}")
    
    # Create agent
    agent = create_agent(args.method, state_dim, action_dim, feature_dims, config, 'cuda')
    
    # Load checkpoint
    if args.method != 'Greedy':
        agent.load(args.checkpoint)
        print(f"Loaded checkpoint from {args.checkpoint}")
    
    # Evaluate
    print(f"\nEvaluating {args.method} for {args.num_episodes} episodes...")
    
    results = {
        'rewards': [],
        'latencies': [],
        'completed': [],
        'violations': [],
        'completion_rates': [],
        'steps': []
    }
    
    for episode in tqdm(range(args.num_episodes)):
        episode_info = evaluate_episode(env, agent, args.method)
        
        results['rewards'].append(episode_info['reward'])
        results['latencies'].append(episode_info['latency'])
        results['completed'].append(episode_info['completed'])
        results['violations'].append(episode_info['violations'])
        results['completion_rates'].append(episode_info['completion_rate'])
        results['steps'].append(episode_info['steps'])
    
    # Compute statistics
    print("\n" + "="*50)
    print(f"Evaluation Results for {args.method}")
    print("="*50)
    print(f"Mean Reward: {np.mean(results['rewards']):.2f} ± {np.std(results['rewards']):.2f}")
    print(f"Mean Latency: {np.mean(results['latencies']):.4f} ± {np.std(results['latencies']):.4f} s")
    print(f"Mean Completed: {np.mean(results['completed']):.2f} ± {np.std(results['completed']):.2f}")
    print(f"Mean Violations: {np.mean(results['violations']):.2f} ± {np.std(results['violations']):.2f}")
    print(f"Mean Completion Rate: {np.mean(results['completion_rates']):.2%} ± {np.std(results['completion_rates']):.2%}")
    print(f"Mean Steps: {np.mean(results['steps']):.2f}")
    print("="*50)
    
    # Save results
    os.makedirs(args.save_dir, exist_ok=True)
    save_results(results, args.save_dir)
    
    # Plot results
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    
    axes[0, 0].hist(results['rewards'], bins=30, alpha=0.7, edgecolor='black')
    axes[0, 0].set_title('Reward Distribution')
    axes[0, 0].set_xlabel('Reward')
    axes[0, 0].set_ylabel('Frequency')
    axes[0, 0].grid(True, alpha=0.3)
    
    axes[0, 1].hist(results['latencies'], bins=30, alpha=0.7, edgecolor='black', color='orange')
    axes[0, 1].set_title('Latency Distribution')
    axes[0, 1].set_xlabel('Latency (s)')
    axes[0, 1].set_ylabel('Frequency')
    axes[0, 1].grid(True, alpha=0.3)
    
    axes[1, 0].hist(results['completion_rates'], bins=30, alpha=0.7, edgecolor='black', color='green')
    axes[1, 0].set_title('Completion Rate Distribution')
    axes[1, 0].set_xlabel('Completion Rate')
    axes[1, 0].set_ylabel('Frequency')
    axes[1, 0].grid(True, alpha=0.3)
    
    axes[1, 1].hist(results['violations'], bins=30, alpha=0.7, edgecolor='black', color='red')
    axes[1, 1].set_title('SLA Violations Distribution')
    axes[1, 1].set_xlabel('Violations')
    axes[1, 1].set_ylabel('Frequency')
    axes[1, 1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(os.path.join(args.save_dir, 'evaluation_distributions.png'), dpi=300)
    plt.close()
    
    print(f"\nResults saved to {args.save_dir}")


if __name__ == '__main__':
    main()
