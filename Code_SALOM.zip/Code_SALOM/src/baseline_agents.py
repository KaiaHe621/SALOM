"""
Baseline Agents for Comparison
Includes: DQN, PAPPO, Meta-RL, LyDROO, Greedy
"""

import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
from collections import deque
import random


class DQNAgent:
    """Standard DQN Agent"""
    def __init__(self, state_dim, action_dim, config, device='cuda'):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.device = torch.device(device if torch.cuda.is_available() else 'cpu')
        
        # Q-Network
        self.q_network = nn.Sequential(
            nn.Linear(state_dim, 512),
            nn.ReLU(),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, action_dim)
        ).to(self.device)
        
        self.target_network = nn.Sequential(
            nn.Linear(state_dim, 512),
            nn.ReLU(),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Linear(128, action_dim)
        ).to(self.device)
        
        self.target_network.load_state_dict(self.q_network.state_dict())
        
        # Optimizer
        self.optimizer = optim.Adam(self.q_network.parameters(), lr=3e-4)
        
        # Replay buffer
        self.replay_buffer = deque(maxlen=100000)
        self.batch_size = 256
        
        # Hyperparameters
        self.gamma = 0.99
        self.epsilon = 1.0
        self.epsilon_decay = 0.995
        self.epsilon_min = 0.01
        self.train_step = 0
        self.target_update_freq = 200
    
    def select_action(self, state, service_priority, evaluate=False):
        if not evaluate and np.random.rand() < self.epsilon:
            return np.random.rand(self.action_dim)
        
        with torch.no_grad():
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            q_values = self.q_network(state_tensor)
            return q_values.cpu().numpy()[0]
    
    def store_transition(self, state, action, reward, next_state, done, service_priority):
        self.replay_buffer.append((state, action, reward, next_state, done))
    
    def train(self):
        if len(self.replay_buffer) < self.batch_size:
            return None
        
        # Sample batch
        batch = random.sample(self.replay_buffer, self.batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)
        
        states = torch.FloatTensor(np.array(states)).to(self.device)
        actions = torch.FloatTensor(np.array(actions)).to(self.device)
        rewards = torch.FloatTensor(rewards).unsqueeze(1).to(self.device)
        next_states = torch.FloatTensor(np.array(next_states)).to(self.device)
        dones = torch.FloatTensor(dones).unsqueeze(1).to(self.device)
        
        # Compute Q-values
        current_q = self.q_network(states).gather(1, actions.long().argmax(1, keepdim=True))
        
        with torch.no_grad():
            next_q = self.target_network(next_states).max(1)[0].unsqueeze(1)
            target_q = rewards + (1 - dones) * self.gamma * next_q
        
        # Compute loss
        loss = nn.MSELoss()(current_q, target_q)
        
        # Optimize
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        # Update target network
        if self.train_step % self.target_update_freq == 0:
            self.target_network.load_state_dict(self.q_network.state_dict())
        
        # Decay epsilon
        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)
        self.train_step += 1
        
        return {'loss': loss.item()}
    
    def save(self, path):
        torch.save(self.q_network.state_dict(), path)
    
    def load(self, path):
        self.q_network.load_state_dict(torch.load(path))


class PAPPOAgent:
    """Proximal Policy Optimization Agent"""
    def __init__(self, state_dim, action_dim, config, device='cuda'):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.device = torch.device(device if torch.cuda.is_available() else 'cpu')
        
        # Actor-Critic Network
        self.actor = nn.Sequential(
            nn.Linear(state_dim, 512),
            nn.ReLU(),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Linear(256, action_dim),
            nn.Softmax(dim=-1)
        ).to(self.device)
        
        self.critic = nn.Sequential(
            nn.Linear(state_dim, 512),
            nn.ReLU(),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Linear(256, 1)
        ).to(self.device)
        
        self.optimizer = optim.Adam(
            list(self.actor.parameters()) + list(self.critic.parameters()),
            lr=3e-4
        )
        
        self.replay_buffer = []
        self.gamma = 0.99
        self.clip_epsilon = 0.2
    
    def select_action(self, state, service_priority, evaluate=False):
        with torch.no_grad():
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            action_probs = self.actor(state_tensor)
            return action_probs.cpu().numpy()[0]
    
    def store_transition(self, state, action, reward, next_state, done, service_priority):
        self.replay_buffer.append((state, action, reward, next_state, done))
    
    def train(self):
        if len(self.replay_buffer) < 256:
            return None
        
        # Simple PPO update (simplified)
        batch = self.replay_buffer[-256:]
        self.replay_buffer = []
        
        states, actions, rewards, next_states, dones = zip(*batch)
        states = torch.FloatTensor(np.array(states)).to(self.device)
        
        # Compute loss (simplified)
        action_probs = self.actor(states)
        values = self.critic(states)
        
        loss = -action_probs.mean() + values.mean()
        
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        return {'loss': loss.item()}
    
    def save(self, path):
        torch.save({'actor': self.actor.state_dict(), 'critic': self.critic.state_dict()}, path)
    
    def load(self, path):
        checkpoint = torch.load(path)
        self.actor.load_state_dict(checkpoint['actor'])
        self.critic.load_state_dict(checkpoint['critic'])


class MetaRLAgent:
    """Meta-Reinforcement Learning Agent (Simplified)"""
    def __init__(self, state_dim, action_dim, config, device='cuda'):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.device = torch.device(device if torch.cuda.is_available() else 'cpu')
        
        # Meta-learner (simplified as DQN with faster adaptation)
        self.q_network = nn.Sequential(
            nn.Linear(state_dim, 512),
            nn.ReLU(),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Linear(256, action_dim)
        ).to(self.device)
        
        self.optimizer = optim.Adam(self.q_network.parameters(), lr=1e-3)
        self.replay_buffer = deque(maxlen=50000)  # Smaller buffer for faster adaptation
        self.batch_size = 128
        self.gamma = 0.99
        self.epsilon = 0.5  # Lower epsilon for faster exploitation
        self.epsilon_decay = 0.99
        self.epsilon_min = 0.01
    
    def select_action(self, state, service_priority, evaluate=False):
        if not evaluate and np.random.rand() < self.epsilon:
            return np.random.rand(self.action_dim)
        
        with torch.no_grad():
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            q_values = self.q_network(state_tensor)
            return q_values.cpu().numpy()[0]
    
    def store_transition(self, state, action, reward, next_state, done, service_priority):
        self.replay_buffer.append((state, action, reward, next_state, done))
    
    def train(self):
        if len(self.replay_buffer) < self.batch_size:
            return None
        
        batch = random.sample(self.replay_buffer, self.batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)
        
        states = torch.FloatTensor(np.array(states)).to(self.device)
        actions = torch.FloatTensor(np.array(actions)).to(self.device)
        rewards = torch.FloatTensor(rewards).unsqueeze(1).to(self.device)
        next_states = torch.FloatTensor(np.array(next_states)).to(self.device)
        dones = torch.FloatTensor(dones).unsqueeze(1).to(self.device)
        
        current_q = self.q_network(states).gather(1, actions.long().argmax(1, keepdim=True))
        
        with torch.no_grad():
            next_q = self.q_network(next_states).max(1)[0].unsqueeze(1)
            target_q = rewards + (1 - dones) * self.gamma * next_q
        
        loss = nn.MSELoss()(current_q, target_q)
        
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)
        
        return {'loss': loss.item()}
    
    def save(self, path):
        torch.save(self.q_network.state_dict(), path)
    
    def load(self, path):
        self.q_network.load_state_dict(torch.load(path))


class LyDROOAgent:
    """Lyapunov-guided DRL Agent (Simplified)"""
    def __init__(self, state_dim, action_dim, config, device='cuda'):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.device = torch.device(device if torch.cuda.is_available() else 'cpu')
        
        # Q-Network with Lyapunov constraint
        self.q_network = nn.Sequential(
            nn.Linear(state_dim, 512),
            nn.ReLU(),
            nn.Linear(512, 256),
            nn.ReLU(),
            nn.Linear(256, action_dim)
        ).to(self.device)
        
        self.optimizer = optim.Adam(self.q_network.parameters(), lr=3e-4)
        self.replay_buffer = deque(maxlen=100000)
        self.batch_size = 256
        self.gamma = 0.99
        self.lyapunov_weight = 0.1
        self.epsilon = 1.0
        self.epsilon_decay = 0.995
        self.epsilon_min = 0.01
    
    def select_action(self, state, service_priority, evaluate=False):
        if not evaluate and np.random.rand() < self.epsilon:
            return np.random.rand(self.action_dim)
        
        with torch.no_grad():
            state_tensor = torch.FloatTensor(state).unsqueeze(0).to(self.device)
            q_values = self.q_network(state_tensor)
            return q_values.cpu().numpy()[0]
    
    def store_transition(self, state, action, reward, next_state, done, service_priority):
        self.replay_buffer.append((state, action, reward, next_state, done))
    
    def train(self):
        if len(self.replay_buffer) < self.batch_size:
            return None
        
        batch = random.sample(self.replay_buffer, self.batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)
        
        states = torch.FloatTensor(np.array(states)).to(self.device)
        actions = torch.FloatTensor(np.array(actions)).to(self.device)
        rewards = torch.FloatTensor(rewards).unsqueeze(1).to(self.device)
        next_states = torch.FloatTensor(np.array(next_states)).to(self.device)
        dones = torch.FloatTensor(dones).unsqueeze(1).to(self.device)
        
        current_q = self.q_network(states).gather(1, actions.long().argmax(1, keepdim=True))
        
        with torch.no_grad():
            next_q = self.q_network(next_states).max(1)[0].unsqueeze(1)
            target_q = rewards + (1 - dones) * self.gamma * next_q
        
        # Q-loss
        q_loss = nn.MSELoss()(current_q, target_q)
        
        # Lyapunov constraint (simplified)
        lyapunov_loss = torch.mean(torch.relu(current_q - target_q))
        
        # Total loss
        loss = q_loss + self.lyapunov_weight * lyapunov_loss
        
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()
        
        self.epsilon = max(self.epsilon_min, self.epsilon * self.epsilon_decay)
        
        return {'loss': loss.item()}
    
    def save(self, path):
        torch.save(self.q_network.state_dict(), path)
    
    def load(self, path):
        self.q_network.load_state_dict(torch.load(path))


class GreedyAgent:
    """Greedy Baseline Agent"""
    def __init__(self, state_dim, action_dim, config):
        self.state_dim = state_dim
        self.action_dim = action_dim
        self.config = config
    
    def select_action(self, state, service_priority, evaluate=False):
        # Simple greedy policy: offload to nearest server with lowest load
        # This is a simplified heuristic
        action = np.random.rand(self.action_dim)
        
        # Normalize offloading decisions
        num_devices = self.config['environment']['num_mobile_devices']
        num_servers = self.config['environment']['num_edge_servers']
        
        for i in range(num_devices):
            start_idx = i * num_servers
            end_idx = (i + 1) * num_servers
            # Greedy: select server with highest probability
            action[start_idx:end_idx] = 0
            action[start_idx] = 1.0  # Always select first server (simplified)
        
        return action
    
    def store_transition(self, *args):
        pass  # Greedy doesn't learn
    
    def train(self):
        return None  # Greedy doesn't train
    
    def save(self, path):
        pass  # Nothing to save
    
    def load(self, path):
        pass  # Nothing to load
