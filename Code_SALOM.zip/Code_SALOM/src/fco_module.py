"""
Feature Calibration Optimization (FCO) Module
Implements the lightweight auxiliary network for feature calibration
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
import numpy as np


class GatedFeatureActivation(nn.Module):
    """Gated Feature Activation mechanism"""
    def __init__(self, input_dim, output_dim):
        super(GatedFeatureActivation, self).__init__()
        self.content_layer = nn.Linear(input_dim, output_dim)
        self.gate_layer = nn.Linear(input_dim, output_dim)
    
    def forward(self, x):
        content = self.content_layer(x)
        gate = torch.sigmoid(self.gate_layer(x))
        return content * gate


class AuxiliaryNetwork(nn.Module):
    """Auxiliary Network for Feature Calibration"""
    def __init__(self, network_dim, server_dim, task_dim, hidden_dims=[512, 256, 128]):
        super(AuxiliaryNetwork, self).__init__()
        
        # Separate channels for different feature types
        self.network_channel = nn.Sequential(
            nn.Linear(network_dim, hidden_dims[0]),
            nn.ReLU()
        )
        
        self.server_channel = nn.Sequential(
            nn.Linear(server_dim, hidden_dims[0]),
            nn.ReLU()
        )
        
        self.task_channel = nn.Sequential(
            nn.Linear(task_dim, hidden_dims[0]),
            nn.ReLU()
        )
        
        # Concatenated feature processing
        concat_dim = hidden_dims[0] * 3
        self.fc_layers = nn.ModuleList()
        prev_dim = concat_dim
        for hidden_dim in hidden_dims[1:]:
            self.fc_layers.append(nn.Linear(prev_dim, hidden_dim))
            self.fc_layers.append(nn.ReLU())
            prev_dim = hidden_dim
        
        # Gated Feature Activation output
        self.output_dim = network_dim + server_dim + task_dim
        self.gfa = GatedFeatureActivation(prev_dim, self.output_dim)
    
    def forward(self, network_features, server_features, task_features):
        # Process each channel separately
        h_network = self.network_channel(network_features)
        h_server = self.server_channel(server_features)
        h_task = self.task_channel(task_features)
        
        # Concatenate
        h_concat = torch.cat([h_network, h_server, h_task], dim=-1)
        
        # Process through FC layers
        h = h_concat
        for layer in self.fc_layers:
            h = layer(h)
        
        # Gated Feature Activation
        auxiliary_features = self.gfa(h)
        
        return auxiliary_features


class FCOModule(nn.Module):
    """
    Feature Calibration Optimization Module
    Implements mutation detection and feature calibration
    """
    def __init__(self, config, feature_dims):
        super(FCOModule, self).__init__()
        
        self.config = config
        self.network_dim, self.server_dim, self.task_dim = feature_dims
        
        # Auxiliary Network
        self.auxiliary_net = AuxiliaryNetwork(
            self.network_dim,
            self.server_dim,
            self.task_dim,
            hidden_dims=config['fco']['auxiliary_network_layers']
        )
        
        # Mutation detection parameters
        self.mutation_threshold = config['fco']['mutation_threshold']
        self.calibration_window = config['fco']['calibration_window']
        self.decay_rate = config['fco']['calibration_decay_rate']
        self.initial_eta = config['fco']['initial_correction_intensity']
        
        # State tracking
        self.feature_history = []
        self.mutation_detected = False
        self.calibration_active = False
        self.calibration_step = 0
        self.max_change_rates = []
        
    def detect_mutation(self, current_features):
        """
        Detect environmental mutation based on feature change rate
        Returns: bool indicating if mutation is detected
        """
        if len(self.feature_history) < 2:
            self.feature_history.append(current_features.detach().cpu().numpy())
            return False
        
        # Calculate feature change rate
        prev_features = self.feature_history[-1]
        current_np = current_features.detach().cpu().numpy()
        
        epsilon = 1e-8
        change_rate = np.abs(current_np - prev_features) / (np.abs(prev_features) + epsilon)
        mean_change_rate = np.mean(change_rate)
        
        # Update history (keep last T steps)
        self.feature_history.append(current_np)
        if len(self.feature_history) > self.calibration_window:
            self.feature_history.pop(0)
        
        # Check if mutation threshold is exceeded
        if mean_change_rate > self.mutation_threshold:
            self.mutation_detected = True
            self.calibration_active = True
            self.calibration_step = 0
            return True
        
        return False
    
    def compute_calibrated_features(self, main_features, auxiliary_features, step):
        """
        Compute calibrated features using confidence-aware residual correction
        
        Args:
            main_features: features from main network (v)
            auxiliary_features: features from auxiliary network (v_bar)
            step: current calibration step
        
        Returns:
            calibrated_features: v_c
        """
        # Time-decaying correction intensity
        eta_t = self.initial_eta * np.exp(-self.decay_rate * step)
        
        # Cosine similarity
        cos_sim = F.cosine_similarity(main_features, auxiliary_features, dim=-1, eps=1e-8)
        cos_sim = cos_sim.unsqueeze(-1)  # Add dimension for broadcasting
        
        # Confidence-aware residual correction
        correction = (1 + cos_sim) * (auxiliary_features - main_features)
        calibrated_features = main_features + eta_t * correction
        
        return calibrated_features
    
    def check_calibration_end(self):
        """
        Check if calibration should end based on feature stability
        Returns: bool indicating if calibration should end
        """
        if len(self.max_change_rates) < self.calibration_window:
            return False
        
        # Check if max change rate is below threshold
        recent_max = max(self.max_change_rates[-self.calibration_window:])
        if recent_max < self.mutation_threshold:
            return True
        
        return False
    
    def forward(self, features, network_features, server_features, task_features):
        """
        Forward pass of FCO module
        
        Args:
            features: concatenated features from main network
            network_features: network state features
            server_features: server state features
            task_features: task characteristics
        
        Returns:
            calibrated_features or original features
            mutation_detected flag
        """
        # Detect mutation
        mutation = self.detect_mutation(features)
        
        # If calibration is active
        if self.calibration_active:
            # Generate auxiliary features
            auxiliary_features = self.auxiliary_net(
                network_features,
                server_features,
                task_features
            )
            
            # Compute calibrated features
            calibrated_features = self.compute_calibrated_features(
                features,
                auxiliary_features,
                self.calibration_step
            )
            
            # Update calibration step
            self.calibration_step += 1
            
            # Check if calibration should end
            if self.check_calibration_end():
                self.calibration_active = False
                self.mutation_detected = False
                self.calibration_step = 0
                self.max_change_rates = []
            
            return calibrated_features, True
        
        return features, False
    
    def compute_alignment_loss(self, main_features, auxiliary_features):
        """
        Compute feature consistency regularization loss
        L_align = ||v(s) - v_bar(s)||_2^2
        """
        return F.mse_loss(main_features, auxiliary_features)
