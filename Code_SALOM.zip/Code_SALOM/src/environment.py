"""
MEC Environment Simulation
Simulates dynamic mobile edge computing environment with:
- Multiple edge servers
- Multiple mobile devices
- Heterogeneous service types
- Environmental mutations
"""

import numpy as np
import random
from collections import namedtuple


Task = namedtuple('Task', ['device_id', 'service_type', 'data_size', 'computation_cycles', 'max_latency', 'priority'])


class MECEnvironment:
    """Mobile Edge Computing Environment"""
    
    def __init__(self, config):
        self.config = config
        env_config = config['environment']
        
        # System parameters
        self.num_edge_servers = env_config['num_edge_servers']
        self.num_devices = env_config['num_mobile_devices']
        self.num_service_types = env_config['num_service_types']
        self.service_priorities = env_config['service_priorities']
        self.time_slot_duration = env_config['time_slot_duration']
        self.max_steps = env_config['max_steps']
        
        # Environmental dynamics
        self.mutation_times = env_config['mutation_times']
        self.current_step = 0
        self.mutation_active = False
        
        # State dimensions
        self.state_dim = self._compute_state_dim()
        self.action_dim = self.num_devices * (self.num_edge_servers + 2)  # offloading + resource + bandwidth
        
        # Initialize environment
        self.reset()
    
    def _compute_state_dim(self):
        """Compute state dimension"""
        # Edge server states (capacity, load, queue length) * num_servers
        server_dim = self.num_edge_servers * 3
        
        # Network states (bandwidth) * num_devices * num_servers
        network_dim = self.num_devices * self.num_edge_servers
        
        # Task states (data_size, computation, service_type, priority) * num_devices
        task_dim = self.num_devices * 4
        
        return server_dim + network_dim + task_dim
    
    def reset(self):
        """Reset environment to initial state"""
        self.current_step = 0
        self.mutation_active = False
        
        # Initialize edge servers
        self.edge_servers = []
        for i in range(self.num_edge_servers):
            server = {
                'id': i,
                'cpu_frequency': np.random.uniform(2.8, 3.5) * 1e9,  # Hz
                'available_capacity': 1.0,  # normalized
                'queue_length': 0,
                'load': 0.0
            }
            self.edge_servers.append(server)
        
        # Initialize mobile devices and tasks
        self.devices = []
        self.tasks = []
        for i in range(self.num_devices):
            device = {
                'id': i,
                'location': np.random.rand(2) * 1000,  # meters
                'current_server': None
            }
            self.devices.append(device)
            
            # Generate initial task
            task = self._generate_task(i)
            self.tasks.append(task)
        
        # Initialize bandwidth matrix
        self._update_bandwidth()
        
        # Statistics
        self.completed_tasks = 0
        self.total_latency = 0.0
        self.sla_violations = 0
        
        return self._get_state()
    
    def _generate_task(self, device_id):
        """Generate a random task for a device"""
        # Randomly select service type
        service_type = np.random.randint(0, self.num_service_types)
        priority = self.service_priorities[service_type]
        
        # Get task parameters based on service type
        if service_type == 0:  # Industrial control
            data_size = np.random.uniform(0.2, 0.8) * 1e6  # bytes
            computation_cycles = np.random.uniform(5e8, 2e9)
            max_latency = 0.05  # 50ms
        elif service_type == 1:  # Video streaming
            data_size = np.random.uniform(1.0, 3.0) * 1e6
            computation_cycles = np.random.uniform(8e8, 5e9)
            max_latency = 0.2  # 200ms
        else:  # File downloading
            data_size = np.random.uniform(2.0, 8.0) * 1e6
            computation_cycles = np.random.uniform(3e8, 1.5e9)
            max_latency = 0.5  # 500ms
        
        return Task(device_id, service_type, data_size, computation_cycles, max_latency, priority)
    
    def _update_bandwidth(self):
        """Update bandwidth matrix based on network conditions"""
        self.bandwidth = np.zeros((self.num_devices, self.num_edge_servers))
        
        for i in range(self.num_devices):
            for j in range(self.num_edge_servers):
                # Distance-based bandwidth
                device_loc = self.devices[i]['location']
                server_loc = np.random.rand(2) * 1000  # Simplified server location
                distance = np.linalg.norm(device_loc - server_loc)
                
                # Network type (70% 4G, 30% 5G)
                if np.random.rand() < 0.7:
                    base_bandwidth = np.random.uniform(50, 150) * 1e6  # 4G
                else:
                    base_bandwidth = np.random.uniform(200, 500) * 1e6  # 5G
                
                # Distance attenuation
                self.bandwidth[i, j] = base_bandwidth / (1 + distance / 100)
    
    def _get_state(self):
        """Get current state representation"""
        state = []
        
        # Edge server states
        for server in self.edge_servers:
            state.extend([
                server['available_capacity'],
                server['load'],
                server['queue_length'] / 10.0  # normalized
            ])
        
        # Network states (bandwidth)
        state.extend(self.bandwidth.flatten() / 1e9)  # normalized to Gbps
        
        # Task states
        for task in self.tasks:
            state.extend([
                task.data_size / 1e7,  # normalized
                task.computation_cycles / 1e10,  # normalized
                task.service_type / self.num_service_types,
                task.priority / max(self.service_priorities)
            ])
        
        return np.array(state, dtype=np.float32)
    
    def step(self, action):
        """
        Execute one step in the environment
        
        Args:
            action: [offloading_decisions, resource_allocation, bandwidth_allocation]
                   Shape: (num_devices * (num_servers + 2))
        
        Returns:
            next_state, reward, done, info
        """
        # Parse action
        offloading = action[:self.num_devices * self.num_edge_servers].reshape(self.num_devices, self.num_edge_servers)
        resource = action[self.num_devices * self.num_edge_servers:self.num_devices * (self.num_edge_servers + 1)]
        bandwidth = action[self.num_devices * (self.num_edge_servers + 1):]
        
        # Process tasks
        step_latency = 0.0
        step_completed = 0
        step_violations = 0
        
        for i, task in enumerate(self.tasks):
            # Select server based on offloading decision
            server_probs = np.exp(offloading[i]) / np.sum(np.exp(offloading[i]))
            server_id = np.random.choice(self.num_edge_servers, p=server_probs)
            
            # Compute latency
            transmission_time = task.data_size / (self.bandwidth[i, server_id] * bandwidth[i])
            computation_time = task.computation_cycles / (self.edge_servers[server_id]['cpu_frequency'] * resource[i])
            queue_time = self.edge_servers[server_id]['queue_length'] * 0.01  # simplified
            
            total_latency = transmission_time + computation_time + queue_time
            
            # Check completion
            if total_latency <= task.max_latency:
                step_completed += 1
                step_latency += total_latency
                
                # Update server state
                self.edge_servers[server_id]['queue_length'] = max(0, self.edge_servers[server_id]['queue_length'] - 1)
                self.edge_servers[server_id]['load'] = max(0, self.edge_servers[server_id]['load'] - 0.1)
            else:
                step_violations += 1
                step_latency += task.max_latency  # penalty
            
            # Generate new task
            self.tasks[i] = self._generate_task(i)
        
        # Update statistics
        self.completed_tasks += step_completed
        self.total_latency += step_latency
        self.sla_violations += step_violations
        
        # Compute reward
        reward = self._compute_reward(step_completed, step_latency, step_violations)
        
        # Check for environmental mutations
        if self.current_step in self.mutation_times:
            self._trigger_mutation()
        
        # Update step
        self.current_step += 1
        done = self.current_step >= self.max_steps
        
        # Get next state
        next_state = self._get_state()
        
        # Info
        info = {
            'completed_tasks': step_completed,
            'average_latency': step_latency / max(step_completed, 1),
            'sla_violations': step_violations,
            'mutation_active': self.mutation_active
        }
        
        return next_state, reward, done, info
    
    def _compute_reward(self, completed, latency, violations):
        """Compute reward based on performance metrics"""
        # Reward for completed tasks
        completion_reward = completed * 10.0
        
        # Penalty for latency
        latency_penalty = latency * 0.1
        
        # Penalty for SLA violations
        violation_penalty = violations * 5.0
        
        reward = completion_reward - latency_penalty - violation_penalty
        
        return reward
    
    def _trigger_mutation(self):
        """Trigger environmental mutation"""
        self.mutation_active = True
        mutation_type = np.random.choice(['bandwidth', 'capacity', 'load'])
        
        if mutation_type == 'bandwidth':
            # Sudden bandwidth change
            self._update_bandwidth()
            self.bandwidth *= np.random.uniform(0.5, 1.5)
        
        elif mutation_type == 'capacity':
            # Server capacity change
            for server in self.edge_servers:
                server['cpu_frequency'] *= np.random.uniform(0.7, 1.3)
        
        else:  # load
            # Sudden load increase
            for server in self.edge_servers:
                server['load'] = min(1.0, server['load'] + np.random.uniform(0.2, 0.5))
                server['queue_length'] += np.random.randint(5, 15)
        
        print(f"[Mutation] Triggered at step {self.current_step}: {mutation_type}")
    
    def get_feature_dims(self):
        """Return dimensions of different feature types for FCO"""
        network_dim = self.num_devices * self.num_edge_servers
        server_dim = self.num_edge_servers * 3
        task_dim = self.num_devices * 4
        return (network_dim, server_dim, task_dim)
