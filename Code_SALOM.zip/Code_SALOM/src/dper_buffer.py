"""
Dynamic Priority Experience Replay (DPER) Buffer
Implements prioritized experience replay with multi-dimensional scoring
"""

import numpy as np
import torch
from collections import namedtuple
import random


Transition = namedtuple('Transition', 
                       ('state', 'action', 'reward', 'next_state', 'done', 
                        'service_priority', 'td_error', 'timestamp'))


class SumTree:
    """
    Sum Tree data structure for efficient priority sampling
    """
    def __init__(self, capacity):
        self.capacity = capacity
        self.tree = np.zeros(2 * capacity - 1)
        self.data = np.zeros(capacity, dtype=object)
        self.write = 0
        self.n_entries = 0
    
    def _propagate(self, idx, change):
        parent = (idx - 1) // 2
        self.tree[parent] += change
        if parent != 0:
            self._propagate(parent, change)
    
    def _retrieve(self, idx, s):
        left = 2 * idx + 1
        right = left + 1
        
        if left >= len(self.tree):
            return idx
        
        if s <= self.tree[left]:
            return self._retrieve(left, s)
        else:
            return self._retrieve(right, s - self.tree[left])
    
    def total(self):
        return self.tree[0]
    
    def add(self, priority, data):
        idx = self.write + self.capacity - 1
        self.data[self.write] = data
        self.update(idx, priority)
        
        self.write += 1
        if self.write >= self.capacity:
            self.write = 0
        
        if self.n_entries < self.capacity:
            self.n_entries += 1
    
    def update(self, idx, priority):
        change = priority - self.tree[idx]
        self.tree[idx] = priority
        self._propagate(idx, change)
    
    def get(self, s):
        idx = self._retrieve(0, s)
        data_idx = idx - self.capacity + 1
        return (idx, self.tree[idx], self.data[data_idx])


class DPERBuffer:
    """
    Dynamic Priority Experience Replay Buffer
    """
    def __init__(self, capacity, config, alpha=0.6, beta_start=0.4, beta_frames=100000):
        self.tree = SumTree(capacity)
        self.capacity = capacity
        self.config = config
        
        # Prioritization parameters
        self.alpha = alpha  # How much prioritization is used
        self.beta_start = beta_start  # Importance sampling weight
        self.beta_frames = beta_frames
        self.frame = 1
        
        # Priority weights (adaptive based on mutation detection)
        self.priority_weights_normal = np.array(config['dper']['priority_weights_normal'])
        self.priority_weights_mutation = np.array(config['dper']['priority_weights_mutation'])
        self.current_weights = self.priority_weights_normal.copy()
        
        # Mutation flag
        self.mutation_active = False
        
        # Small constant to avoid zero priority
        self.epsilon = 1e-5
        
        # State tracking for environmental similarity
        self.current_state = None
    
    def set_mutation_mode(self, active):
        """Switch between normal and mutation priority weights"""
        self.mutation_active = active
        if active:
            self.current_weights = self.priority_weights_mutation.copy()
        else:
            self.current_weights = self.priority_weights_normal.copy()
    
    def _get_beta(self):
        """Linearly increase beta from beta_start to 1.0"""
        return min(1.0, self.beta_start + self.frame * (1.0 - self.beta_start) / self.beta_frames)
    
    def _compute_td_error_score(self, td_error):
        """
        Compute TD error component of priority
        Higher TD error = higher priority
        """
        return np.abs(td_error) + self.epsilon
    
    def _compute_task_criticality(self, service_priority, reward):
        """
        Compute task criticality based on service priority and reward
        """
        # Normalize service priority (assuming priorities are 1, 2, 3)
        normalized_priority = service_priority / 3.0
        
        # Combine with reward magnitude
        criticality = normalized_priority * (1.0 + np.abs(reward))
        
        return criticality
    
    def _compute_environmental_similarity(self, state):
        """
        Compute environmental similarity between stored state and current state
        Using Gaussian kernel: exp(-||s_i - s_t||^2 / (2*sigma^2))
        """
        if self.current_state is None:
            return 1.0
        
        # Convert to numpy if tensor
        if isinstance(state, torch.Tensor):
            state = state.cpu().numpy()
        if isinstance(self.current_state, torch.Tensor):
            current = self.current_state.cpu().numpy()
        else:
            current = self.current_state
        
        # Compute L2 distance
        distance = np.linalg.norm(state - current)
        
        # Gaussian kernel with sigma=1.0
        sigma = 1.0
        similarity = np.exp(-distance**2 / (2 * sigma**2))
        
        return similarity
    
    def _compute_feature_reliability(self, timestamp):
        """
        Compute feature reliability based on recency
        More recent experiences are more reliable
        """
        # Exponential decay based on age
        age = self.frame - timestamp
        decay_rate = 0.001
        reliability = np.exp(-decay_rate * age)
        
        return reliability
    
    def compute_priority(self, transition):
        """
        Compute multi-dimensional priority score
        Priority = lambda1 * TD_error + lambda2 * Task_Criticality + 
                   lambda3 * Env_Similarity + lambda4 * Feature_Reliability
        """
        # Extract components
        td_error_score = self._compute_td_error_score(transition.td_error)
        task_criticality = self._compute_task_criticality(
            transition.service_priority, 
            transition.reward
        )
        env_similarity = self._compute_environmental_similarity(transition.state)
        feature_reliability = self._compute_feature_reliability(transition.timestamp)
        
        # Weighted combination
        priority = (
            self.current_weights[0] * td_error_score +
            self.current_weights[1] * task_criticality +
            self.current_weights[2] * env_similarity +
            self.current_weights[3] * feature_reliability
        )
        
        return priority ** self.alpha
    
    def push(self, state, action, reward, next_state, done, service_priority, td_error=1.0):
        """Add a new experience to the buffer"""
        transition = Transition(
            state, action, reward, next_state, done,
            service_priority, td_error, self.frame
        )
        
        priority = self.compute_priority(transition)
        self.tree.add(priority, transition)
        
        self.frame += 1
    
    def sample(self, batch_size):
        """
        Sample a batch of experiences based on priorities
        Returns: batch, indices, weights
        """
        batch = []
        indices = []
        weights = []
        
        # Divide priority range into batch_size segments
        segment = self.tree.total() / batch_size
        beta = self._get_beta()
        
        # Sample from each segment
        for i in range(batch_size):
            a = segment * i
            b = segment * (i + 1)
            s = random.uniform(a, b)
            
            idx, priority, data = self.tree.get(s)
            
            # Compute importance sampling weight
            sampling_prob = priority / self.tree.total()
            weight = (self.tree.n_entries * sampling_prob) ** (-beta)
            
            batch.append(data)
            indices.append(idx)
            weights.append(weight)
        
        # Normalize weights
        max_weight = max(weights)
        weights = [w / max_weight for w in weights]
        
        return batch, indices, weights
    
    def update_priorities(self, indices, td_errors):
        """Update priorities for sampled experiences"""
        for idx, td_error in zip(indices, td_errors):
            # Get the transition
            data_idx = idx - self.capacity + 1
            transition = self.tree.data[data_idx]
            
            # Create updated transition with new TD error
            updated_transition = Transition(
                transition.state,
                transition.action,
                transition.reward,
                transition.next_state,
                transition.done,
                transition.service_priority,
                td_error,
                transition.timestamp
            )
            
            # Recompute priority
            priority = self.compute_priority(updated_transition)
            
            # Update in tree
            self.tree.update(idx, priority)
            self.tree.data[data_idx] = updated_transition
    
    def update_current_state(self, state):
        """Update current state for environmental similarity computation"""
        self.current_state = state
    
    def __len__(self):
        return self.tree.n_entries
