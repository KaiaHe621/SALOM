"""
Dataset Loader for SALOM Experiments
Loads and processes pre-generated MEC datasets
"""

import json
import numpy as np
import os


class MECDatasetLoader:
    """Load and process MEC datasets"""
    
    def __init__(self, dataset_path):
        """
        Initialize dataset loader
        
        Args:
            dataset_path: Path to the dataset JSON file
        """
        self.dataset_path = dataset_path
        self.dataset = self._load_dataset()
        self.current_index = 0
    
    def _load_dataset(self):
        """Load dataset from file"""
        if not os.path.exists(self.dataset_path):
            raise FileNotFoundError(f"Dataset not found: {self.dataset_path}")
        
        with open(self.dataset_path, 'r') as f:
            dataset = json.load(f)
        
        print(f"Loaded dataset: {dataset['metadata']['dataset_name']}")
        print(f"  Version: {dataset['metadata']['version']}")
        print(f"  Samples: {dataset['metadata']['num_samples']}")
        print(f"  Seed: {dataset['metadata']['seed']}")
        
        return dataset
    
    def get_metadata(self):
        """Get dataset metadata"""
        return self.dataset['metadata']
    
    def get_network_trace(self, index):
        """Get network trace at specific index"""
        return self.dataset['network_traces'][index]
    
    def get_server_traces(self, index):
        """Get all server traces at specific index"""
        return [server[index] for server in self.dataset['server_traces']]
    
    def get_task(self, index):
        """Get task at specific index"""
        return self.dataset['task_traces'][index]
    
    def get_mutations(self):
        """Get all mutation events"""
        return self.dataset['mutation_events']
    
    def get_mutation_at_time(self, timestamp):
        """Check if there's a mutation at given timestamp"""
        for mutation in self.dataset['mutation_events']:
            if mutation['timestamp'] == timestamp:
                return mutation
        return None
    
    def get_batch(self, start_idx, batch_size):
        """
        Get a batch of data
        
        Args:
            start_idx: Starting index
            batch_size: Number of samples
        
        Returns:
            Dictionary with network, server, and task data
        """
        end_idx = min(start_idx + batch_size, len(self.dataset['task_traces']))
        
        batch = {
            'network': self.dataset['network_traces'][start_idx:end_idx],
            'servers': [server[start_idx:end_idx] for server in self.dataset['server_traces']],
            'tasks': self.dataset['task_traces'][start_idx:end_idx],
            'indices': list(range(start_idx, end_idx))
        }
        
        return batch
    
    def iterate_batches(self, batch_size, shuffle=False):
        """
        Iterate over dataset in batches
        
        Args:
            batch_size: Size of each batch
            shuffle: Whether to shuffle the data
        
        Yields:
            Batches of data
        """
        num_samples = len(self.dataset['task_traces'])
        indices = np.arange(num_samples)
        
        if shuffle:
            np.random.shuffle(indices)
        
        for start_idx in range(0, num_samples, batch_size):
            end_idx = min(start_idx + batch_size, num_samples)
            batch_indices = indices[start_idx:end_idx]
            
            batch = {
                'network': [self.dataset['network_traces'][i] for i in batch_indices],
                'servers': [[server[i] for i in batch_indices] for server in self.dataset['server_traces']],
                'tasks': [self.dataset['task_traces'][i] for i in batch_indices],
                'indices': batch_indices.tolist()
            }
            
            yield batch
    
    def get_statistics(self):
        """Compute and return dataset statistics"""
        tasks = self.dataset['task_traces']
        network = self.dataset['network_traces']
        
        stats = {
            'total_tasks': len(tasks),
            'service_distribution': {},
            'network_stats': {
                'avg_bandwidth': np.mean([n['bandwidth'] for n in network]),
                'std_bandwidth': np.std([n['bandwidth'] for n in network])
            }
        }
        
        # Service type distribution
        for service_type in ['industrial_control', 'video_streaming', 'file_download']:
            count = sum(1 for t in tasks if t['service_type'] == service_type)
            stats['service_distribution'][service_type] = {
                'count': count,
                'percentage': count / len(tasks) * 100
            }
        
        return stats
    
    def reset(self):
        """Reset iterator to beginning"""
        self.current_index = 0
    
    def __len__(self):
        """Return dataset length"""
        return len(self.dataset['task_traces'])
    
    def __getitem__(self, index):
        """Get item at index"""
        return {
            'network': self.get_network_trace(index),
            'servers': self.get_server_traces(index),
            'task': self.get_task(index),
            'mutation': self.get_mutation_at_time(index)
        }


def load_multiple_datasets(dataset_dir, seeds=None):
    """
    Load multiple datasets with different seeds
    
    Args:
        dataset_dir: Directory containing datasets
        seeds: List of seeds to load (None = load all)
    
    Returns:
        Dictionary of loaders keyed by seed
    """
    loaders = {}
    
    if seeds is None:
        # Find all dataset files
        files = [f for f in os.listdir(dataset_dir) if f.startswith('mec_dataset_seed') and f.endswith('.json')]
        seeds = [int(f.split('seed')[1].split('.')[0]) for f in files]
    
    for seed in seeds:
        dataset_path = os.path.join(dataset_dir, f'mec_dataset_seed{seed}.json')
        if os.path.exists(dataset_path):
            loaders[seed] = MECDatasetLoader(dataset_path)
            print(f"Loaded dataset with seed {seed}")
    
    return loaders


if __name__ == '__main__':
    # Example usage
    loader = MECDatasetLoader('data/mec_dataset_seed42.json')
    
    print("\nDataset Statistics:")
    stats = loader.get_statistics()
    print(f"  Total tasks: {stats['total_tasks']}")
    print(f"  Service distribution:")
    for service, info in stats['service_distribution'].items():
        print(f"    {service}: {info['count']} ({info['percentage']:.1f}%)")
    
    print(f"\n  Network:")
    print(f"    Avg bandwidth: {stats['network_stats']['avg_bandwidth']/1e6:.2f} Mbps")
    
    print("\nIterating first 3 samples:")
    for i in range(3):
        sample = loader[i]
        print(f"\n  Sample {i}:")
        print(f"    Task: {sample['task']['service_type']}")
        print(f"    Bandwidth: {sample['network']['bandwidth']/1e6:.2f} Mbps")
        print(f"    Servers: {len(sample['servers'])} servers")
